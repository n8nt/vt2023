#!/bin/bash -xv
export DISPLAY=:5

# create fifo
# change to directory where fifo exists
cd /usr/local/apps/versatune/data

# remove existing fifo
# rm knucker_status_fifo

# create new knucker_status_fifo
# mkfifo knucker_status_fifo

# change to scripts folder
cd /usr/local/apps/versatune/scripts

# shutdown any CombiTunerExpress apps that might be running
/usr/local/apps/versatune/scripts/killRunningCombiTuner.sh

# pause a few seconds
# sleep 5

# change to scripts folder
cd /usr/local/apps/versatune/scripts

echo Reading option file to create the startup script
#get parameters from input file
INFILE=/usr/local/apps/versatune/data/startupOptions.txt
MODE="none"
FREQ="0"
BW="0"
SR="0"
while read -r LINE
do
  option=$(echo $LINE | cut -d ' ' -f 1)
  if test "$option" = "M"
  then
    vMode=$(echo $LINE | cut -d ' ' -f 2)
#    MODE=vMode;
  elif test "$option" = "F"
  then
    vFreq=$(echo $LINE | cut -d ' ' -f 2)
#    FREQ=vFreq
  elif test "$option" = "B"
  then
    vBw=$(echo $LINE | cut -d ' ' -f 2)
#    BW=vBw
  else test "$option" = "S"
    vSr=$(echo $LINE | cut -d ' ' -f 2)
#    SR=vSr
  fi
done < "$INFILE"

echo Got the following parameters mode=$vMode, freq=$vFreq, bw=$vBw, sr=$vSr
#echo Got the following parameters mode=$MODE, freq=$FREQ, bw=$BW, sr=$SR
#sleep 300
# start up a new combiTunerExpress instance
#  we won't start up the CombiTunerExpress if we are debugging. It will be started from CLion
# set mode, frequency, bandwidth and symbol rate to your default channel. This is where it will start up on power up.
#    stdbuf -oL  /tmp/tmp.tPWK53Tb72/cmake-build-debug/CombiTunerExpress -m $vMode -f $vFreq -b $vBw -s $vSr >/usr/local/apps/versatune/logs/combituner.out 2>/usr/local/apps/versatune/logs/combituner.err   &
     stdbuf -oL         /usr/local/apps/versatune/data/CombiTunerExpress -m $vMode -f $vFreq -b $vBw -s $vSr >/usr/local/apps/versatune/logs/combituner.out 2>/usr/local/apps/versatune/logs/combituner.err   &

