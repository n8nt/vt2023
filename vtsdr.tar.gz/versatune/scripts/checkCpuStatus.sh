#!/bin/bash
vcgencmd measure_temp
vcgencmd get_mem arm
vcgencmd get_mem gpu
