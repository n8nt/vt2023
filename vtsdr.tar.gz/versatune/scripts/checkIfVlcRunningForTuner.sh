#!/bin/bash
netstat -an | grep :1314 > testForVlcForTuner
if [ -s testForVlcForTuner ]; then
	echo  VLC is running for Tuner.
	exit 1;
else
	echo  VLC is not unning for Tuner. Starting now.
	exit 0;
fi
