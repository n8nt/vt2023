#!/bin/bash
netstat -an | grep 9002 > tcpxxx
if [ -s tcpxxx ]; then
   echo TCP STILL BUSY. PLEASE WAIT 
   exit 1
else
   echo TCP CLEAR. OK TO RESTART
   exit 0
fi

