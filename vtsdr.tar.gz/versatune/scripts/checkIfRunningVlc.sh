#!/bin/bash
pgrep vlc > testForVlcRunning
if [ -s testForVlcRunning ]; then
   echo VLC is running - returning 1
   exit 1;
else
   echo VLC is not running - returning 0
   exit 0;
fi
