#!/bin/bash
pidof vlc > xxx
if [ -s xxx ]; then
	echo  VLC is running - killing now.
        killall -9 vlc
else
	echo  VLC is not unning - nothing to kill now.
fi
