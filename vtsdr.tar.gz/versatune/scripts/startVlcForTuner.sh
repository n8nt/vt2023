#!/bin/bash
#cvlc --sub-filter marq --marq-size 20 --marq-x 25 --marq-position=8 --marq-file "/usr/local/apps/versatune/data/vlc_overlay.txt" --gain 3 --alsa-audio-device hw:CARD=b1,DEV=0 udp://@127.0.0.1:1314 >/dev/null  2>&1 &
cvlc --sub-filter marq --marq-size 20 --marq-x 25 --marq-position=8 --marq-file "/usr/local/apps/versatune/data/vlc_overlay.txt" --gain 3 --alsa-audio-device hw:CARD=b1,DEV=0 udp://@127.0.0.1:1314 > startvlc.log  2> startvlcError.log & 
