#!/bin/bash
pidof CombiTunerExpress > xxxCombi
if [ -s xxxCombi ]; then
        echo  CombiTunerExpress is running
	exit 0
else
        echo  CombiTunerExpress is not running
        exit 1 
fi

