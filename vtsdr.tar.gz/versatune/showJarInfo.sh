unzip -q -c $1 META-INF/MANIFEST.MF

