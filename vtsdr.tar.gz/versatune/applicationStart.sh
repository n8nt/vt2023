#!/bin/bash
sleep 10
#export JAVA_HOME=/usr/lib/jvm/zulu-21-arm64
#export JAVA_HOME=/usr/local/apps/java/jdk/zulu21.30.15-ca-jdk21.0.1-linux_aarch64
#export JAVA_HOME=/home/pi/.sdkman/candidates/java/21.0.1-amzn/bin/java
export APP_DIR=/usr/local/apps/versatune
PATH=$PATH:$APP_DIR:${APP_DIR}/conf
export PATH
echo JAVA HOME IS $JAVA_HOME
echo PATH is $PATH
# put the VersatuneID.jpg into the frame buffer.
#sudo /usr/local/apps/versatune/scripts/restartCombiTunerExpress.sh >/dev/null 2>/dev/null
sudo /usr/local/apps/versatune/scripts/restartCombiTunerExpress.sh
sudo fbi -T 1 -noverbose -a /usr/local/apps/versatune/data/VersatuneID.jpg >/dev/null 2>/dev/null
# remove the /usr/bin/java from next line since we are using the java from sdkman. It should find the right one.

sudo $Java_HOME/bin/java -Djava.net.preferIPv4Stack=true  -Djava.library.path=/usr/local/apps/versatune/data  -Dspring.profiles.active=dev -Dlogging.config=/usr/local/apps/versatune/conf/logback-spring.xml -Dspring.config.additional-location=/usr/local/apps/versatune/conf/  -jar -agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=*:5005  /usr/local/apps/versatune/versatune.jar > /usr/local/apps/versatune/logs/Application.log 2>&1
#sudo /usr/bin/java  -Dspring.profiles.active=dev -Dspring.config.additional-location=/usr/local/apps/versatune/conf/ -Dlogging.config=/usr/local/apps/versatune/conf/logback-spring.xml -jar -agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=*:5005  /usr/local/apps/versatune/versatune.jar > /usr/local/apps/versatune/logs/Application.log 2>&1
echo DONE

#export JAVA_HOME=/usr/local/apps/java/jdk/zulu21.30.15-ca-jdk21.0.1-linux_aarch64
#export M2_HOME=/opt/apache-maven-3.8.7
#export MAVEN_HOME=/opt/apache-maven-3.8.7
#export PATH=${M2_HOME}/bin:${JAVA_HOME}:${PATH}cho DONE
